package van.unity.permission.dispatcher;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;

public class UnityAndroidPermissions {
    public boolean IsPermissionGranted(Activity activity, String permissionName) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M)
            return true;
        if (activity == null)
            return false;
        return activity.checkSelfPermission(permissionName) == PackageManager.PERMISSION_GRANTED;
    }

    public void RequestPermissionAsync(Activity activity, final String[] permissionNames, final IPermissionRequestResult resultCallbacks) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M)
            return;
        if (activity == null || permissionNames == null || resultCallbacks == null)
            return;

        final Fragment request = new PermissionFragment(resultCallbacks);
        Bundle bundle = new Bundle();
        bundle.putStringArray(PermissionFragment.PERMISSION_NAMES, permissionNames);
        request.setArguments(bundle);

        FragmentTransaction fragmentTransaction = activity.getFragmentManager().beginTransaction();
        fragmentTransaction.add(0, request);
        fragmentTransaction.commit();
    }

    public void OpenAppSetting(Activity activity) {
        Intent intent = new Intent();
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
        intent.setData(uri);
        activity.startActivity(intent);
    }
}
