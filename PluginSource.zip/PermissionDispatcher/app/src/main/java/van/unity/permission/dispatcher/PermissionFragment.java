package van.unity.permission.dispatcher;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;

@SuppressLint("ValidFragment")
@TargetApi(23)
public class PermissionFragment extends Fragment {
    public static final String PERMISSION_NAMES = "PermissionNames";

    private static final int PERMISSIONS_REQUEST_CODE = 15887;

    private final IPermissionRequestResult m_ResultCallbacks;
    private String firstPlayKey = "isFirstPlay";

    // Not a nice thing to do - having a non-default Fragment constructor
    public PermissionFragment(final IPermissionRequestResult resultCallbacks) {
        m_ResultCallbacks = resultCallbacks;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String[] permissionNames = getArguments().getStringArray(PERMISSION_NAMES);
        requestPermissions(permissionNames, PERMISSIONS_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != PERMISSIONS_REQUEST_CODE)
            return;

        PermissionResult[] results = new PermissionResult[permissions.length];

        for (int i = 0; i < permissions.length; i++) {
            boolean isGranted = grantResults[i] == PackageManager.PERMISSION_GRANTED;
            boolean isNeverAskAgain = (IsFirstPlay() == false && shouldShowRequestPermissionRationale(permissions[i]) == false);
            results[i] = new PermissionResult(permissions[i], isGranted, isNeverAskAgain);
        }

        RawPermissionResult rawResults = new RawPermissionResult(results);

        m_ResultCallbacks.OnRequestPermissionsResult(rawResults);

        FragmentTransaction fragmentTransaction = getActivity().getFragmentManager().beginTransaction();
        fragmentTransaction.remove(this);
        fragmentTransaction.commit();
    }

    private boolean IsFirstPlay() {
        SharedPreferences prefs = getActivity().getSharedPreferences("PermissionPluginPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();

        boolean isFirst = prefs.getBoolean(firstPlayKey, true);

        if (isFirst) {
            prefsEditor.putBoolean(firstPlayKey, false);
            prefsEditor.apply();
        }

        return isFirst;
    }
}
