package van.unity.permission.dispatcher;

public interface IPermissionRequestResult {
    void OnRequestPermissionsResult(RawPermissionResult rawResults);
}
