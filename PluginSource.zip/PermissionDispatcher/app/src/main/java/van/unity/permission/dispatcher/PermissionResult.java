package van.unity.permission.dispatcher;

public class PermissionResult {
    public String permissionName;
    public boolean permissionGranted;
    public boolean neverAskAgain;

    public PermissionResult(String permissionName, boolean permissionGranted, boolean neverAskAgain) {
        this.permissionName = permissionName;
        this.permissionGranted = permissionGranted;
        this.neverAskAgain = neverAskAgain;
    }
}
