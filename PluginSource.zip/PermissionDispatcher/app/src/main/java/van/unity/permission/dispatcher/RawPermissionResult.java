package van.unity.permission.dispatcher;

public class RawPermissionResult {
    public PermissionResult[] results;

    public RawPermissionResult(PermissionResult[] results) {
        this.results = results;
    }
}
